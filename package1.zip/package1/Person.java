package package1;

public abstract class Person {
	/*
	 * "bridge used pattern" : we will make the person class an abstract class and
	 * have an attribute form type residency that represent the bridge between
	 * classes so other classes that extends person like : admin . or doctor do now
	 * need to know whats the residency for the person because residency can vary
	 * independently. single responsibility : person stores its data and residency
	 * stores its data so each class has its own purpose.
	 */
	protected String id;
	protected String name;
	protected int age;
	protected Residency residency;

	public Person(String id, String name, int age, Residency residency) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.residency = residency;
	}

	public abstract String getRole(); // each sub class will return its person type . 

	public String getInfo() {
		return "[" + getRole() + "] ID: " + id + ", Name: " + name + ", Age: " + age + ", Residency: "+ residency.getResidencyType() +
				" (" + residency.getResidencyInfo() + ")";
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public Residency getResidency() {
		return residency;
	}
}
