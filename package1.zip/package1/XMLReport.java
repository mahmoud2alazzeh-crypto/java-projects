package package1;

public class XMLReport extends Report {
	// Concrete subclass in the Template Method pattern

	public XMLReport(String title, String summary, String content, String adminName) {
		super(title, summary, content, adminName);
	}

	@Override
	protected String formatHeader() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + "<report>\n" + "  <title>" + escape(title)
				+ "</title>\n";
	}

	@Override
	protected String formatSummary() {
		return "  <summary>" + escape(summary) + "</summary>\n";//XML FORMAT : <STARTING>  (CONTENT)   </ENDING/>.
	}

	@Override
	protected String formatContent() {
		return "  <content>" + escape(content) + "</content>\n";
	}

	@Override
	protected String formatFooter() {
		return "  <generatedBy>" + escape(adminName) + "</generatedBy>\n" + "  <date>" + date + "</date>\n"
				+ "</report>\n";
	}

	@Override
	public String getFileExtension() {
		return " .xml";
	}

	// small helper to keep xml valid
	private String escape(String s) {
		if (s == null)
			return " ";// to ensure somthing would be replaced so we will prevent null pointer error.
		return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); // will replace the first one with the second to match the XML charaters. 
	}
}
