/*
 "the bridge pattern"
 person and residency hierarchy made to fit the jordanian , nonjordanian , patient , doctor , nurse and admin so without "bridge pattern" we must make 8 classes so 
 it let us to bridge the two hierarchies by giving each residency a reference instead of inheriting it.  
 */
package package1;

public interface Residency {
    String getResidencyType();
    String getResidencyInfo();
}
