package package1;

public class Medication extends MedicalProcedure {
	
    public Medication(String name, String details) {
        super(name, details);// the constructor of the parent class which is "medical procedure"
    }
    @Override
	public String getType() {
		return "Medication";
	}
}
