package package1;

public class Reportcontext {
	private Reportstrategy strategy;

	public Reportcontext(Reportstrategy strategy) {
		this.strategy = strategy;
	}

	public void setStrategy(Reportstrategy strategy) {
		this.strategy = strategy;
	}

	public String generateReport(HospitalServiceProxy service, DataStore data, String format) {
		String title = strategy.getTitle();
		String summary = strategy.getSummary(data);
		String content = strategy.getContent(data);
		return service.generateAndSaveReport(format, title, summary, content);
	}
}
