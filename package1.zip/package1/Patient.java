package package1;

import java.util.ArrayList;
import java.util.List;

public class Patient extends Person {

	private List<MedicalProcedure> procedures; // to save all the procedures done for each patient
	private Room assignedRoom; //reference from type room so we can get the room that have the patient.  
	private String admissionStart;
	private String admissionEnd;
	private boolean admitted;

	public Patient(String id, String name, int age, Residency residency) {
		super(id, name, age, residency); // override for the person constructor to initialize values for the patients 
		this.procedures = new ArrayList<>(); // initialize the array list so we can add the records to it. 
		this.admitted = false;
	}

	@Override
	public String getRole() { // the method that returns each person type role. "override"
		return "Patient";
	}

	public void admit(Room r, String start, String end) {
		this.assignedRoom = r;
		this.admissionStart = start;
		this.admissionEnd = end;
		this.admitted = true;
		r.addPatient(this); //adds the specific patient to the list of patients in that "room" . 
	}

	public void discharge() { // if the doctor wants to discharge the patient will call this method.
		if (assignedRoom != null) { // will check if the room is null so java want throw an error if we call it when its already null.
			assignedRoom.removePatient(this);
		}
		this.assignedRoom = null; 
		this.admitted = false; // the patient may be registered but not admitted. 
	}

	public void extendAdmission(String newEnd) { // to define a new end date for the existing admission. 
		this.admissionEnd = newEnd;
	}

	public void addProcedure(MedicalProcedure p) { // to add new needed procedure for the patient.
		procedures.add(p);
	}

	public List<MedicalProcedure> getProcedures() {
		return procedures;
	}

	public Room getAssignedRoom() {
		return assignedRoom;
	}

	public String getAdmissionStart() {
		return admissionStart;
	}

	public String getAdmissionEnd() {
		return admissionEnd;
	}

	public boolean isAdmitted() { // to check if the registered patient is admitted or not yet. 
		return admitted;
	}

	public String getHistory() {
		StringBuilder sb = new StringBuilder(); // a predefined tool that saves all the strings in the class.  
		sb.append(getInfo()).append("\n"); // append to add the info or values after the previous var. 
		if (admitted) {
			sb.append("  Admitted in the room : ").append(assignedRoom.getRoomNumber()).append(" from ")
					.append(admissionStart).append(" to ").append(admissionEnd).append("\n");
		} else {
			sb.append("  Not currently admitted\n");
		}
		sb.append("  Procedures: \n");
		if (procedures.isEmpty()) {
			sb.append("  no procedures applies yet \n");
		} else {
			for (MedicalProcedure p : procedures) {
				sb.append("  _  ").append(p.toString()).append("\n");
			}
		}
		return sb.toString();
	}
}
