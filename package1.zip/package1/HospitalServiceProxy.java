package package1;

public class HospitalServiceProxy implements HospitalService {
	/*
	 used pattern : proxy to meet the AB requirements : Doctors: admit, discharge, add procedures, view history. 
	 Nurses :register patient, view info, view procedures, mark done.
	 Admin :add users, add rooms/sections, generate reports. 
	 so instead of using simple if statements the proxy will wraps the real service and check the permission before completing , 
	 but without knowing the caller with who he is taliking wether the procy or the real service.
	 solid : SRP this class only handles the access control feature , and the real service does the implementation and the actual work. 
	 */
	private RealHospitalService realService;
	private Person currentUser;

	public HospitalServiceProxy(Person currentUser) {
		this.realService = new RealHospitalService();
		this.currentUser = currentUser;
	}

	private boolean deniedaccess(String action) {
		System.out.println("ACCESS DENIED: " + currentUser.getRole() + "' cannot perform action: " + action);
		return false;
	}

	@Override
	public void admitPatient(Patient p, Room r, String start, String end) {
		if (currentUser instanceof Doctor) {
			realService.admitPatient(p, r, start, end);
		} else {
			deniedaccess("admit patient");
		}
	}

	@Override
	public void dischargePatient(Patient p) {
		if (currentUser instanceof Doctor) {
			realService.dischargePatient(p);
		} else {
			deniedaccess("discharge patient");
		}
	}

	@Override
	public void addProcedureToPatient(Patient p, MedicalProcedure proc) {
		if (currentUser instanceof Doctor) {
			realService.addProcedureToPatient(p, proc);
		} else {
			deniedaccess("add procedure");
		}
	}

	@Override
	public void markProcedureDone(Patient p, MedicalProcedure proc) {
		// both nurses and doctors are allowed
		if (currentUser instanceof Nurse || currentUser instanceof Doctor) {
			realService.markProcedureDone(p, proc);
		} else {
			deniedaccess("mark procedure as done");
		}
	}

	@Override
	public void registerPatient(Patient p) {
		// nurses register patients
		if (currentUser instanceof Nurse || currentUser instanceof Admin) {
			realService.registerPatient(p);
		} else {
			deniedaccess("register patient");
		}
	}

	@Override
	public void addUser(Person user) {
		if (currentUser instanceof Admin) {
			realService.addUser(user);
		} else {
			deniedaccess("add user");
		}
	}

	@Override
	public void addSection(Section s) {
		if (currentUser instanceof Admin) {
			realService.addSection(s);
		} else {
			deniedaccess("add section");
		}
	}

	@Override
	public void addRoomToSection(Section s, Room r) {
		if (currentUser instanceof Admin) {
			realService.addRoomToSection(s, r);
		} else {
			deniedaccess("add room");
		}
	}

	@Override
	public String generateAndSaveReport(String format, String title, String summary, String content) {
		if (currentUser instanceof Admin) {
			return realService.generateAndSaveReport(format, title, summary, content);
		} else {
			deniedaccess("generate report");
			return null;
		}
	}

	public Person getCurrentUser() {
		return currentUser;
	}
}
