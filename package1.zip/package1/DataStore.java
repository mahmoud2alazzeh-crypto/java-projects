package package1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*
 the applied pattern is singleton so all the data for the previous classes "person.... , residency.... , medical procedure...." 
 can be accessed from one place which is data store , so all system parts share the same list and same files. 
 */
public class DataStore {

	private static DataStore instance; // one instance to access the data store.

	// in memory data
	private List<Person> people;
	private List<Section> sections;
	private List<MedicalProcedure> proceduremenu; // available procedure types

	private DataStore() {  	// private constructor so nobody can define a new object from data store from outside

		people = new ArrayList<>();
		sections = new ArrayList<>();
		proceduremenu = new ArrayList<>();
	}

	
	public static DataStore getInstance() { // access it from one single point.  
		if (instance == null) {
			instance = new DataStore();
		}
		return instance;
	}


	public void addPerson(Person p) { // access people records
		people.add(p);
	}

	public Person findPersonById(String id) {
		for (Person p : people) {
			if (p.getId().equalsIgnoreCase(id)) {
				return p;
			}
		}
		return null;
	}

	public List<Person> getPeople() {
		return people;
	}

	public List<Patient> getPatients() {
		List<Patient> list = new ArrayList<>(); //applying "generics" on this list by pulling down the patient records only.
		for (Person p : people) {
			if (p instanceof Patient) { // instance of asks java if the initial object actuallt a patient. 
				list.add((Patient) p); // casting person to patiens.
			}
		}
		return list;
	}

	public void addSection(Section s) { // to access sections and rooms. 
		sections.add(s);
	}

	public List<Section> getSections() {
		return sections;
	}

	public void addProcedureToMenu(MedicalProcedure p) { // access the procedure menu 
		proceduremenu.add(p);
	}

	public List<MedicalProcedure> getProcedureCatalog() {
		return proceduremenu;
	}

	public void saveToFile(String filename, String content) { //file 1/O single point of access.

		try { // we must apply try catch to throw the error to let JAVA execute the filewriter method. 
			FileWriter fw = new FileWriter(filename); // let the textalways exist even after ends of execution.   // saves on the desk files 
			fw.write(content);
			fw.close();
			System.out.println("Saved to filen : " + filename);
		} catch (IOException e) {
			System.out.println("Error saving file: " + e.getMessage());
		}
	}

	public String loadFromFile(String filename) {
		StringBuilder sb = new StringBuilder();// instant saving and rtrieving data.   // saves on RAM 
		try {
			// the buffer helps in reading multiple characters at one time other than the file reader that shoulf return to the desk every character reading.
			BufferedReader br = new BufferedReader(new FileReader(filename)); // "file reader" to read the content from the file. 
			String line; // saves all the file content in one string
			while ((line = br.readLine()) != null) { // readthe next line and save it then check if htereany other line.
				sb.append(line).append("\n"); // add the new line to the previous one.
			}
			br.close();
		} catch (IOException e) {
			System.out.println("Error loading file: " + e.getMessage());
		}
		return sb.toString();
	}
}
