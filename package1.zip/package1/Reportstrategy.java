package package1;

public interface Reportstrategy {
	String getTitle();

	String getSummary(DataStore data);

	String getContent(DataStore data);
}
