package package1;

public abstract class MedicalProcedure {
	/*
	 * abstract class for the implemented medical procedures so another classes
	 * would override the methods and the used principles "open closed" which will
	 * let us to add new procedures without adding new classes so without changing
	 * the existing code
	 */
	protected String name;
	protected String details;
	protected boolean done;

	public MedicalProcedure(String name, String details) {
		this.name = name;
		this.details = details;
		this.done = false;
	}

	public abstract String getType(); // each sub class will return its procedure type. 

	public void markAsDone() {
		this.done = true;
	}

	public boolean isDone() {
		return done;
	}

	public String getName() {
		return name;
	}

	public String getDetails() {
		return details;
	}

	@Override
	public String toString() {
		return getType() + "  " + name + "  " + details + "  " + (done ? "DONE" : "wating");
		// if it is done it will return done and if it is not it will return waiting. 
	}
}
