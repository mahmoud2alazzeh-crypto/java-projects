package package1;

public class UserFactory {

	public static Person createUser(String role, String id, String name, int age, Residency residency) {
		if (role == null) {
			throw new IllegalArgumentException("Role cannot be null");
		}
		String r = role.trim().toLowerCase();
		if (r.equals("patient")) {
			return new Patient(id, name, age, residency);
		} else if (r.equals("doctor")) {
			return new Doctor(id, name, age, residency);
		} else if (r.equals("nurse")) {
			return new Nurse(id, name, age, residency);
		} else if (r.equals("admin")) {
			return new Admin(id, name, age, residency);
		} else {
			throw new IllegalArgumentException("Unknown role: " + role);
		}
	}
}
/*
 * used pateern is factory : the system handles four types of users , so if we let anyother class to define new object from any person class 
 * we must let them all know all subclasses , so this factory pattern centralize the creation process in one place.
 * 
 *the used solid princple in this class is open closed so we can add new features by inly editting the factory not all the classes.  
 */
