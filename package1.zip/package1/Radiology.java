package package1;
//this is a child class the represent one of procedures of the healthcare system.
public class Radiology extends MedicalProcedure {
	public Radiology(String name, String details) {
		super(name, details);
	}

	@Override
	public String getType() {
		return "Radiology";
	}
}
