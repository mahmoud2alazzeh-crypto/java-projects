package package1;

import java.util.ArrayList;
import java.util.List;

public class Room {

	private String roomNumber;
	private String type; // / there is three types of rooms even : private , two beds , four beds.
	private int capacity;
	private List<Patient> patients;

	public Room(String roomNumber, String type) {
		this.roomNumber = roomNumber;
		this.type = type;
		if (type.equalsIgnoreCase("Private")) {// "equalsIgnoreCase" will ignore either its upper or lower case.
			this.capacity = 1;
		} else if (type.equalsIgnoreCase("two shared beds")) {
			this.capacity = 2;
		} else if (type.equalsIgnoreCase("four shared beds")) {
			this.capacity = 4;
		} else {
			this.capacity = 1;
		}
		
		this.patients = new ArrayList<>(); // initialize it so when we define an object we can save records from type patient.
	}

	public boolean isAvailable() {
		return patients.size() < capacity; // will check the capacity of the room over the number of patients(capacity).
	}

	public void addPatient(Patient p) {
		if (isAvailable()) {
			patients.add(p);// will add the attribute from type patient to the array named patients.
		} else {
			System.out.println("Room " + roomNumber + " is full.");
		}
	}

	public void removePatient(Patient p) {
		patients.remove(p);
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public String getType() {
		return type;
	}

	public int getCapacity() {
		return capacity;
	}

	public int getOccupancy() {
		return patients.size();
	}

	public List<Patient> getPatients() {
		return patients;
	}

	@Override
	public String toString() {
		return "Room :  " + roomNumber + " (" + type + ") " + getOccupancy() + " _ " + capacity
				+ (isAvailable() ? " still available " : " already full ");
	}
}
