package package1;
//this is a child class the represent one of procedures of the healthcare system.
public class Monitoring extends MedicalProcedure {
	
	public Monitoring(String name, String details) {
		super(name, details);
	}

	@Override
	public String getType() {
		return "Monitoring";
	}
}
