package package1;
//this is a child class the represent one of procedures of the healthcare system.
public class LabTest extends MedicalProcedure {
	public LabTest(String name, String details) {
		super(name, details);
	}

	@Override
	public String getType() { //polymorphism
		return "LabTest";
	}
}
