package package1;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Testing {

	private RealHospitalService realService;
	private Patient patient1;
	private Patient patient2;
	private Room privateRoom;
	private Doctor doctor;
	private Nurse nurse;
	private Admin admin;

	@BeforeEach
	public void setup() {
		// Initialize the core service
		realService = new RealHospitalService();

		// Setup shared mock dependency
		Residency dummyRes = new JordanianResidency("1234567890", "ID-123");

		// Instantiate actors using the Factory Pattern
		patient1 = (Patient) UserFactory.createUser("patient", "P01", "Ali", 30, dummyRes);
		patient2 = (Patient) UserFactory.createUser("patient", "P02", "Omar", 25, dummyRes);

		doctor = (Doctor) UserFactory.createUser("doctor", "D01", "Dr. Smith", 45, dummyRes);
		nurse = (Nurse) UserFactory.createUser("nurse", "N01", "Nancy", 28, dummyRes);
		admin = (Admin) UserFactory.createUser("admin", "A01", "Alice", 35, dummyRes);

		// Setup a single-capacity room
		privateRoom = new Room("101", "Private");
	}

	// ====================================================================
	// Patient Admission Workflow
	// ====================================================================

	@Test
	public void testAdmitPatientToAvailableRoom() {
		realService.admitPatient(patient1, privateRoom, "2026-06-01", "2026-06-05");

		assertTrue(patient1.isAdmitted(), "Patient status should change to admitted.");
		assertEquals(1, privateRoom.getOccupancy(), "Room occupancy should increase to 1.");
		assertFalse(privateRoom.isAvailable(), "The private room should now be full.");
	}

	@Test
	public void testAdmitPatientToFullRoom() {
		// Fill the room first
		realService.admitPatient(patient1, privateRoom, "2026-06-01", "2026-06-05");

		// Attempt to admit a second patient to the identical, full room
		realService.admitPatient(patient2, privateRoom, "2026-06-01", "2026-06-05");

		assertFalse(patient2.isAdmitted(), "Admission must be blocked for the second patient.");
		assertEquals(1, privateRoom.getOccupancy(), "Room occupancy must remain unchanged at 1.");
	}

	@Test
	public void testDischargeAdmittedPatient() {
		realService.admitPatient(patient1, privateRoom, "2026-06-01", "2026-06-05");

		// Discharge action
		realService.dischargePatient(patient1);

		assertFalse(patient1.isAdmitted(), "Patient should no longer be marked as admitted.");
		assertEquals(0, privateRoom.getOccupancy(), "Room occupancy should drop to 0.");
		assertTrue(privateRoom.isAvailable(), "Room should become available again.");
	}

	// ====================================================================
	// Role-Based Access Control (Proxy)
	// ====================================================================

	@Test
	public void testDoctorCanAdmitPatient() {
		HospitalServiceProxy proxy = new HospitalServiceProxy(doctor);
		proxy.admitPatient(patient1, privateRoom, "2026-06-01", "2026-06-05");

		assertTrue(patient1.isAdmitted(), "Proxy should authorize Doctor to admit patient.");
	}

	@Test
    public void testNurseCanMarkProcedureDone() {
        // 1. Setup the proxy for the Nurse
        HospitalServiceProxy proxy = new HospitalServiceProxy(nurse);
        
        // 2. Create a procedure and manually add it to the patient for testing
        MedicalProcedure medicine = new Medication("Paracetamol", "500mg");
        patient1.addProcedure(medicine);
        
        // Ensure it starts as NOT done
        assertEquals(false, medicine.isDone());

        // 3. The Nurse attempts to mark the procedure as done through the proxy
        proxy.markProcedureDone(patient1, medicine);

        // 4. Verification: The Proxy should allow the action.
        // We use assertEquals(true, ...) to completely avoid any JUnit version conflicts.
        assertEquals(true, medicine.isDone());
    }

	@Test
	public void testDoctorVsAdminReportGeneration() {
		HospitalServiceProxy docProxy = new HospitalServiceProxy(doctor);
		HospitalServiceProxy adminProxy = new HospitalServiceProxy(admin);

		String docResult = docProxy.generateAndSaveReport("text", "Title", "Sum", "Content");
		String adminResult = adminProxy.generateAndSaveReport("text", "Title", "Sum", "Content");

		assertNull(docResult, "Doctor should receive a null response.");
		assertNotNull(adminResult, "Admin should successfully generate the report string.");
	}
	@Test
    public void testGenerateTextReportWithStrategy() {
        // 1. Setup the proxy with an Admin user (only Admins can generate reports)
        HospitalServiceProxy proxy = new HospitalServiceProxy(admin);
        
        // 2. Select the specific report strategy (Patient Report)
        Reportstrategy strategy = new Patientreportstrategy();
        
        // 3. Wrap it in the Context class
        Reportcontext context = new Reportcontext(strategy);
        
        // 4. Generate the report using the context and the proxy
        // We use DataStore.getInstance() to pass the data, and "text" for the format.
        String report = context.generateReport(proxy, DataStore.getInstance(), "text");

        // 5. Verification: 
        // We check that the strategy successfully injected its specific title and summary
        assertNotNull(report);
        assertTrue(report.contains("Patients Report"));
        assertTrue(report.contains("Total patients:"));
        
        // We check that the Template Pattern still applied the text formatting
        assertTrue(report.contains("=================================================="));
    }
	@Test
	public void testGenerateXMLReport() {
		HospitalServiceProxy proxy = new HospitalServiceProxy(admin);
		String report = proxy.generateAndSaveReport("xml", "Test Title", "Test Summary", "Test Content");

		assertTrue(report.contains("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"),
				"Must contain standard XML declaration.");
		assertTrue(report.contains("<report>"), "Must contain the root report XML tag.");
		assertTrue(report.contains("<title>Test Title</title>"),
				"Must contain properly structured XML tags mapping to the data.");
	}

	@Test
	public void testCompareTextAndXMLReports() {
		HospitalServiceProxy proxy = new HospitalServiceProxy(admin);

		String title = "Identical Title Data";
		String summary = "Identical Summary Data";
		String content = "Identical Content Data";

		String textReport = proxy.generateAndSaveReport("text", title, summary, content);
		String xmlReport = proxy.generateAndSaveReport("xml", title, summary, content);

		// Verification 1: Formatting differs
		assertNotEquals(textReport, xmlReport, "The structured formats must be completely different.");

		// Verification 2: Underlying data is exactly the same
		assertTrue(textReport.contains(title) && xmlReport.contains(title),
				"Both reports must share the same title data.");
		assertTrue(textReport.contains(summary) && xmlReport.contains(summary),
				"Both reports must share the same summary data.");
		assertTrue(textReport.contains(content) && xmlReport.contains(content),
				"Both reports must share the same content data.");
	}
}